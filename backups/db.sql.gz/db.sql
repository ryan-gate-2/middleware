-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: db
-- Generation Time: Jun 13, 2022 at 06:06 PM
-- Server version: 10.8.3-MariaDB-1:10.8.3+maria~jammy
-- PHP Version: 8.0.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rdev1`
--

-- --------------------------------------------------------

--
-- Table structure for table `access_profiles`
--

CREATE TABLE `access_profiles` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profile_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `api_dk` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `api_evo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `max_entries_sessions` int(11) NOT NULL DEFAULT 2,
  `max_hourly_demosessions` int(11) NOT NULL DEFAULT 10,
  `max_hourly_callback_errors` int(11) NOT NULL DEFAULT 500,
  `max_hourly_createsession_errors` int(11) NOT NULL DEFAULT 500,
  `branded` tinyint(4) NOT NULL DEFAULT 1,
  `branded_launcher_baseurl` varchar(555) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `access_profiles`
--

INSERT INTO `access_profiles` (`id`, `profile_name`, `api_dk`, `api_evo`, `max_entries_sessions`, `max_hourly_demosessions`, `max_hourly_callback_errors`, `max_hourly_createsession_errors`, `branded`, `branded_launcher_baseurl`, `active`, `created_at`, `updated_at`, `deleted_at`) VALUES
('1', 'base_profile', 'USD:0dda2681-e3a0-4411-88ce-13beaf075dab,EUR:00e63d84-8c0d-4dff-afe4-5bb2108d355e,CAD:f52c45f9-fe30-461a-8a9e-e5de68a98f44,TRY:7f1970b4-53df-4866-8f4a-dc1242e21e6b,TND:2464570a-523c-4241-8cfb-3cc8454c6a36', '0', 20, 300, 5000, 15000, 1, '', 1, '2022-04-12 23:12:38', '2022-04-12 23:12:38', NULL),
('2', 'grey_only', NULL, '0', 2, 300, 5000, 15000, 1, '', 1, '2022-04-12 23:12:38', '2022-04-12 23:12:38', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `access_providers`
--

CREATE TABLE `access_providers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_profile` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `access_providers`
--

INSERT INTO `access_providers` (`id`, `provider`, `price`, `access_profile`, `created_at`, `updated_at`) VALUES
(2, 'pragmatic', '20.2', '1', NULL, NULL),
(3, 'netent', '2', '1', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `action_events`
--

CREATE TABLE `action_events` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `batch_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `actionable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `actionable_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fields` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'running',
  `exception` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `original` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `changes` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `currencyprices`
--

CREATE TABLE `currencyprices` (
  `id` int(10) UNSIGNED NOT NULL,
  `currency` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `currencyprices`
--

INSERT INTO `currencyprices` (`id`, `currency`, `price`, `created_at`, `updated_at`) VALUES
(1, 'EUR', '0.95892', '2022-04-13 01:44:22', '2022-06-13 16:41:14'),
(2, 'GBP', '0.82251', '2022-04-13 01:44:22', '2022-06-13 16:41:14'),
(3, 'TRY', '17.252355', '2022-04-13 01:44:22', '2022-06-13 16:41:14'),
(4, 'CAD', '1.286245', '2022-04-13 01:44:22', '2022-06-13 16:41:14'),
(5, 'PLN', '4.46155', '2022-04-13 01:44:22', '2022-06-13 16:41:14'),
(6, 'TND', '3.069501', '2022-04-13 01:44:22', '2022-06-13 16:41:14'),
(7, 'BRL', '5.106203', '2022-04-13 01:44:22', '2022-06-13 16:41:14'),
(8, 'AUD', '1.441595', '2022-04-13 01:44:22', '2022-06-13 16:41:14'),
(9, 'CHF', '0.997115', '2022-04-13 01:44:22', '2022-06-13 16:41:14'),
(10, 'KRW', '1292.940619', '2022-04-13 01:44:22', '2022-06-13 16:41:14'),
(11, 'INR', '78.139502', '2022-04-13 01:44:22', '2022-06-13 16:41:14');

-- --------------------------------------------------------

--
-- Table structure for table `demo_sessions`
--

CREATE TABLE `demo_sessions` (
  `uid` char(36) COLLATE utf8mb3_unicode_ci NOT NULL,
  `casino_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_id` varchar(2000) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `player_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `player_meta` varchar(3500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `player_ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `branded` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL,
  `game` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `request_ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `visited` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `updated_at` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `created_at` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gameoptions`
--

CREATE TABLE `gameoptions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `apikey` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_key` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL,
  `ownedBy` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `native_currency` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USD',
  `active` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `demo_sessions` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '0',
  `real_sessions` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '0',
  `return_log` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `gameoptions`
--

INSERT INTO `gameoptions` (`id`, `apikey`, `parent_key`, `ownedBy`, `native_currency`, `active`, `demo_sessions`, `real_sessions`, `return_log`, `created_at`, `updated_at`) VALUES
(1, 'USD-45180761-ee13-4c26-9b48-236eaf3a2f46-apikey', '45180761-ee13-4c26-9b48-236eaf3a2f46-apikey', '45180761-ee13-4c26-9b48-236eaf3a2f46', 'USD', '1', '25', '34', 1, NULL, '2022-04-14 05:50:09'),
(2, 'EUR-45180761-ee13-4c26-9b48-236eaf3a2f46-apikey', '45180761-ee13-4c26-9b48-236eaf3a2f46-apikey', '45180761-ee13-4c26-9b48-236eaf3a2f46', 'EUR', '1', '0', '14', 1, NULL, '2022-04-14 05:51:09');

-- --------------------------------------------------------

--
-- Table structure for table `gameoptions_parent`
--

CREATE TABLE `gameoptions_parent` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `apikey_parent` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL,
  `ownedBy` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `operatorurl` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `operator_secret` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `access_profile` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `real_sessions_stat` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hourly_spare_demosessions` int(11) NOT NULL DEFAULT 0,
  `hourly_spare_callback_errors` int(11) NOT NULL DEFAULT 100,
  `hourly_spare_createsession_errors` int(11) NOT NULL DEFAULT 100,
  `poker_prefix` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `slots_prefix` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `callbackurl` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `native_currency` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USD',
  `allowed_ips` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `extendedApi` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `poker_enabled` int(11) NOT NULL DEFAULT 0,
  `active` int(11) NOT NULL DEFAULT 1,
  `return_log` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `gameoptions_parent`
--

INSERT INTO `gameoptions_parent` (`id`, `apikey_parent`, `ownedBy`, `operatorurl`, `operator_secret`, `access_profile`, `real_sessions_stat`, `hourly_spare_demosessions`, `hourly_spare_callback_errors`, `hourly_spare_createsession_errors`, `poker_prefix`, `slots_prefix`, `callbackurl`, `native_currency`, `allowed_ips`, `extendedApi`, `poker_enabled`, `active`, `return_log`, `created_at`, `updated_at`) VALUES
(1, '45180761-ee13-4c26-9b48-236eaf3a2f46-apikey', '45180761-ee13-4c26-9b48-236eaf3a2f46', 'https://test.casino.slotlayer.com', '12345', '1', '5', 300, 5000, 14993, '0', 'game', 'https://api.middleware.slotlayer.com/staging/testBalanceCallback/', 'USD', '82.180.150.102,194.49.52.125,193.29.60.141,85.26.183.58,217.146.87.149', '0', 0, 1, 1, NULL, '2022-04-14 07:02:05');

-- --------------------------------------------------------

--
-- Table structure for table `gametransactions`
--

CREATE TABLE `gametransactions` (
  `id` char(36) COLLATE utf8mb3_unicode_ci NOT NULL,
  `casinoid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ownedBy` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `player` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bet` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `win` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `usd_exchange` varchar(100) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '1',
  `gameid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `txid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `roundid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `final` int(11) NOT NULL DEFAULT 0,
  `callback_state` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '1',
  `rawdata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`rawdata`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gametransactions_live`
--

CREATE TABLE `gametransactions_live` (
  `id` char(36) COLLATE utf8mb3_unicode_ci NOT NULL,
  `casinoid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ownedBy` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `player` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bet` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `win` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `usd_exchange` varchar(100) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '1',
  `gameid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `txid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `roundid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `final` int(11) NOT NULL DEFAULT 0,
  `callback_state` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '1',
  `rawdata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`rawdata`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `gametransactions_live`
--

INSERT INTO `gametransactions_live` (`id`, `casinoid`, `ownedBy`, `player`, `type`, `bet`, `win`, `currency`, `usd_exchange`, `gameid`, `txid`, `roundid`, `final`, `callback_state`, `rawdata`, `created_at`, `updated_at`) VALUES
('6664324d-ee3f-4288-9cb9-fbbf02f0fdb2', '2', '45180761-ee13-4c26-9b48-236eaf3a2f46', '021412', 'external_game', '10', '0', 'EUR', '0.92272', 'net-t-starburst', '1tksrf:69689', '1tksrf:6', 0, '1', '[]', '2022-04-14 02:40:40', '2022-04-14 02:40:40');

-- --------------------------------------------------------

--
-- Table structure for table `log_callback_errors`
--

CREATE TABLE `log_callback_errors` (
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apikey` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ownedBy` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `error_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `error_message` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `log_createsession_errors`
--

CREATE TABLE `log_createsession_errors` (
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apikey` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ownedBy` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `error_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `error_message` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `log_createsession_errors`
--

INSERT INTO `log_createsession_errors` (`uid`, `apikey`, `ownedBy`, `error_code`, `error_message`, `request`, `created_at`, `updated_at`) VALUES
('1f2234cd-b66a-406c-b789-a02fe5072f33', '45180761-ee13-4c26-9b48-236eaf3a2f46-apikey', '45180761-ee13-4c26-9b48-236eaf3a2f46', '401', '217.146.87.149 is not in allowed IP-address list on your API settings. If you see this error and do not reconize IP, please contact support as your API access might have been compromised.', 'https://api.middleware.slotlayer.com/game/createSession?apikey=45180761-ee13-4c26-9b48-236eaf3a2f46-apikey&apikey_owner=45180761-ee13-4c26-9b48-236eaf3a2f46&currency=USD&game=hab-o-jungle-rumble&playerid=021412', '2022-04-14 05:43:50', '2022-04-14 05:43:50'),
('45ff1319-0542-4894-b87b-740fc9c1d949', '45180761-ee13-4c26-9b48-236eaf3a2f46-apikey', '45180761-ee13-4c26-9b48-236eaf3a2f46', '401', '193.29.60.141 is not in allowed IP-address list on your API settings. If you see this error and do not reconize IP, please contact support as your API access might have been compromised.', 'https://api.middleware.slotlayer.com/game/createSession?apikey=45180761-ee13-4c26-9b48-236eaf3a2f46-apikey&apikey_owner=45180761-ee13-4c26-9b48-236eaf3a2f46&currency=USD&game=hab-o-jungle-rumble&playerid=021412', '2022-04-14 01:26:53', '2022-04-14 01:26:53'),
('5018ba45-fd24-406a-b192-092a567e01f4', '45180761-ee13-4c26-9b48-236eaf3a2f46-apikey', '45180761-ee13-4c26-9b48-236eaf3a2f46', '401', '149.154.161.4 is not in allowed IP-address list on your API settings. If you see this error and do not reconize IP, please contact support as your API access might have been compromised.', 'https://api.middleware.slotlayer.com/game/createSession?apikey=45180761-ee13-4c26-9b48-236eaf3a2f46-apikey&apikey_owner=45180761-ee13-4c26-9b48-236eaf3a2f46&currency=USD&game=hab-o-jungle-rumble&playerid=021412', '2022-04-14 02:37:13', '2022-04-14 02:37:13'),
('58725a68-8ebf-48b4-81a2-2f21f3e07f95', '45180761-ee13-4c26-9b48-236eaf3a2f46-apikey', '45180761-ee13-4c26-9b48-236eaf3a2f46', '401', '77.78.207.2 is not in allowed IP-address list on your API settings. If you see this error and do not reconize IP, please contact support as your API access might have been compromised.', 'https://api.middleware.slotlayer.com/game/createSession?apikey=45180761-ee13-4c26-9b48-236eaf3a2f46-apikey&apikey_owner=45180761-ee13-4c26-9b48-236eaf3a2f46&currency=USD&game=hab-o-jungle-rumble&playerid=021412', '2022-04-14 03:17:52', '2022-04-14 03:17:52'),
('81d3f58b-2f3c-4d26-97eb-d789cd10369d', '45180761-ee13-4c26-9b48-236eaf3a2f46-apikey', '45180761-ee13-4c26-9b48-236eaf3a2f46', '401', '176.119.195.25 is not in allowed IP-address list on your API settings. If you see this error and do not reconize IP, please contact support as your API access might have been compromised.', 'https://api.middleware.slotlayer.com/game/createSession?apikey=45180761-ee13-4c26-9b48-236eaf3a2f46-apikey&apikey_owner=45180761-ee13-4c26-9b48-236eaf3a2f46&currency=USD&game=hab-o-jungle-rumble&playerid=021412', '2022-04-14 03:41:23', '2022-04-14 03:41:23'),
('97aca211-edc7-4fb8-914c-e7d107e4241f', '45180761-ee13-4c26-9b48-236eaf3a2f46-apikey', '45180761-ee13-4c26-9b48-236eaf3a2f46', '401', '176.119.195.25 is not in allowed IP-address list on your API settings. If you see this error and do not reconize IP, please contact support as your API access might have been compromised.', 'https://api.middleware.slotlayer.com/game/createSession?apikey=45180761-ee13-4c26-9b48-236eaf3a2f46-apikey&apikey_owner=45180761-ee13-4c26-9b48-236eaf3a2f46&currency=USD&game=hab-o-jungle-rumble&playerid=021412', '2022-04-14 03:59:04', '2022-04-14 03:59:04'),
('a14d2884-a6a2-4a8d-84eb-f5b566ca9aec', '45180761-ee13-4c26-9b48-236eaf3a2f46-apikey', '45180761-ee13-4c26-9b48-236eaf3a2f46', '401', '176.119.195.25 is not in allowed IP-address list on your API settings. If you see this error and do not reconize IP, please contact support as your API access might have been compromised.', 'https://api.middleware.slotlayer.com/game/createSession?apikey=45180761-ee13-4c26-9b48-236eaf3a2f46-apikey&apikey_owner=45180761-ee13-4c26-9b48-236eaf3a2f46&currency=USD&game=hab-o-jungle-rumble&playerid=021412', '2022-04-14 03:17:41', '2022-04-14 03:17:41'),
('aae88f7f-a412-4db2-958d-ee6b8bb335b1', '45180761-ee13-4c26-9b48-236eaf3a2f46-apikey', '45180761-ee13-4c26-9b48-236eaf3a2f46', '401', '176.119.195.25 is not in allowed IP-address list on your API settings. If you see this error and do not reconize IP, please contact support as your API access might have been compromised.', 'https://api.middleware.slotlayer.com/game/createSession?apikey=45180761-ee13-4c26-9b48-236eaf3a2f46-apikey&apikey_owner=45180761-ee13-4c26-9b48-236eaf3a2f46&currency=EUR&game=net-t-starburst&playerid=021412', '2022-04-14 03:17:51', '2022-04-14 03:17:51'),
('cbcd1377-bc91-470a-af05-d18a2b96d2e9', '45180761-ee13-4c26-9b48-236eaf3a2f46-apikey', '45180761-ee13-4c26-9b48-236eaf3a2f46', '401', '149.154.161.4 is not in allowed IP-address list on your API settings. If you see this error and do not reconize IP, please contact support as your API access might have been compromised.', 'https://api.middleware.slotlayer.com/game/createSession?apikey=45180761-ee13-4c26-9b48-236eaf3a2f46-apikey&apikey_owner=45180761-ee13-4c26-9b48-236eaf3a2f46&currency=EUR&game=net-t-starburst&playerid=021412', '2022-04-14 02:37:47', '2022-04-14 02:37:47'),
('e4d90bce-1e43-433f-80e9-a75f40e89f03', '45180761-ee13-4c26-9b48-236eaf3a2f46-apikey', '45180761-ee13-4c26-9b48-236eaf3a2f46', '401', '85.148.48.255 is not in allowed IP-address list on your API settings. If you see this error and do not reconize IP, please contact support as your API access might have been compromised.', 'https://api.middleware.slotlayer.com/game/createSession?apikey=45180761-ee13-4c26-9b48-236eaf3a2f46-apikey&apikey_owner=45180761-ee13-4c26-9b48-236eaf3a2f46&currency=USD&game=hab-o-jungle-rumble&playerid=021412', '2022-04-14 07:02:05', '2022-04-14 07:02:05');

-- --------------------------------------------------------

--
-- Table structure for table `log_important`
--

CREATE TABLE `log_important` (
  `uid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `log_level` int(11) NOT NULL DEFAULT 1,
  `log_message` varchar(5000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notified` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `log_important`
--

INSERT INTO `log_important` (`uid`, `log_level`, `log_message`, `notified`, `created_at`, `updated_at`) VALUES
('9f88a3a0-f580-44a2-88be-5d2a4d577fe3', 4, 'Error while resetting hourly maximums for 45180761-ee13-4c26-9b48-236eaf3a2f46-apikey owned by 45180761-ee13-4c26-9b48-236eaf3a2f46 - was unable to find access profile matching the access profile.', 0, '2022-04-14 02:57:23', '2022-04-14 02:57:23');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2018_04_30_000000_create_roles_table', 1),
(2, '2018_04_30_000010_create_users_table', 1),
(3, '2018_04_30_000011_create_password_resets_table', 1),
(4, '2018_04_30_000020_create_user_roles_table', 1),
(5, '2019_08_19_000000_create_failed_jobs_table', 1),
(6, '2018_04_30_000010_create_providers_table', 2),
(7, '2018_04_30_000022_create_providers_table', 3),
(8, '2018_04_30_000023_create_providers_table', 4),
(9, '2018_04_30_000023_create_currency_table', 5),
(10, '2014_10_12_000000_create_users_table', 6),
(11, '2018_01_01_000000_create_action_events_table', 6),
(12, '2019_05_10_000000_add_fields_to_action_events_table', 6),
(13, '2019_11_21_000000_change_action_event_ids_to_strings', 6),
(14, '2019_12_14_000001_create_personal_access_tokens_table', 6);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `providers`
--

CREATE TABLE `providers` (
  `id` int(11) NOT NULL,
  `provider_id` char(255) COLLATE utf8mb3_unicode_ci NOT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ggr_cost` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `index_rating` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT '60',
  `softswiss_id` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `providers`
--

INSERT INTO `providers` (`id`, `provider_id`, `type`, `ggr_cost`, `index_rating`, `softswiss_id`) VALUES
(1, 'netent', 'slots', '11', '60', NULL),
(2, 'pragmatic', 'slots', '10', '60', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `regular_sessions`
--

CREATE TABLE `regular_sessions` (
  `uid` char(36) COLLATE utf8mb3_unicode_ci NOT NULL,
  `casino_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_id` varchar(2500) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `player_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `player_meta` varchar(3500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `player_ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `game` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `branded` int(11) NOT NULL DEFAULT 1,
  `request_ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `visited` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `extra_currency` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL,
  `updated_at` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `created_at` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `regular_sessions`
--

INSERT INTO `regular_sessions` (`uid`, `casino_id`, `session_id`, `player_id`, `player_meta`, `player_ip`, `game`, `branded`, `request_ip`, `visited`, `active`, `currency`, `extra_currency`, `updated_at`, `created_at`) VALUES
('0a491dbd-43c7-44c9-9c04-6713ced8adf6', '1', '7287edd3c90df80f6e726546e6328466ff083596c3ab2d6dd5577b7e1d63866afe792e6d8d6d9fd9bf8946cce42c103a27502fde38b73523b21bd21f5cd4ebfad30274ce84c138b02b97db20fa9cd103310a49d7fd1ae657ae0117c40b83163d6bc65a6be7d337f13baab31131ce490e24723568459759e4303b8ba9d5489c3a7fa73cb9ddf6bf549e58787f44564e7b0c11551d0703ecec764522eddeb9485dd8f68e4c83870b2896ff6880fb5138a54432eb504b638fa3a1a60c10062c3d746244a8e8e2cad71b6d65103e6770ceabc9380ca707b0a92bf82bf2957b7de28fdb0d4b6243c2c1a2771ec420d631b9753536be13efc6d315a56c0c3316199ffd113cb6a6909e8e3b1e24ede8c32e267790b3a8e11a9edeedfa9dc415ca1fbae3', '021412', '[]', '0', 'hab-o-jungle-rumble', 1, '194.49.52.125', '0', '0', 'USD', '0', '2022-04-14 08:50:09', '2022-04-14 03:50:21'),
('14bf9905-1bd2-410b-a57f-d53338194476', '2', '65abdc0449de11432062b549b879d76db9b35c6609402900c1127114af99023fe7a0f1e020ca9dfc03a42949636aa9c3559d3cdeb2684170a631af01e38bdb4bebaca801297b1dbb45eb8fe6793dcc82a7738461df39213e21ba912472569ea51dd1cb75d73527b55c2cad96cc0eb4a851f6730a86cb0a7e9663b2784306ec18', '021412', '[]', '0', 'net-t-starburst', 1, '217.146.87.149', '0', '0', 'EUR', '0', '2022-04-14 08:51:09', '2022-04-14 08:44:15'),
('1a7e48f3-76a0-4a01-a459-79d4d892d4ff', '2', 'c91ee33f4554be860a16422a8f631c0f270d4e7a3b430e556e784e8495c207ec8966d7964c7a141e999899b2479c0028fa962a640848d3616aea81c5c1b5d085ce7b7e1e9d3719013100df3f3a4a385f7d4a559ae45d619a7c70b53cbe15d53392fa763133ca03da0f17d81ce60ea369b0548b0d38f5612f519d8d476e8d10ec', '51021412', '[]', '0', 'net-t-starburst', 1, '217.146.87.149', '0', '1', 'EUR', '0', '2022-04-14 08:44:36', '2022-04-14 08:44:36'),
('20ff947d-b300-43e5-9a53-587ae24b800d', '2', '9636e93e2cc895fc844ad7474750be74397ac25347ea9ce00177fd98e46f518807e186f6fa3614bee99326c63c85e323820ac980283aa718514fcaf6ca248bead71e9c11b99cdf6ac9d80c836596aa9bde24cdc1f2357b257e1295bb9909c40e04303d9d01432d27f006a584b0477d61', '021412', '[]', '0', 'net-t-starburst', 1, '194.49.52.125', '0', '0', 'EUR', '0', '2022-04-14 08:51:09', '2022-04-14 03:50:32'),
('282b1b76-16e4-45e9-823f-d47f7718bc00', '1', '4e108fc0014ef486d0102b39fe46db758c7d9c9fb911bb63692ef6a95e466730f87fca5a15b33ee5b9b2f62fa3a9db52c10c7ddd70081dd163ec979a286983868b7cec314f430a4662a42683031f61cd76d00c4d6ba03b635876aeb8e2d28120a733e1c69a3d865a0359f5b0eed17610e75299e86f4bf4a6d884ccdaacaf8e172aacf7176531a1259cbac6e37b2afff9de85a89ed7e4ff512cb52a7d3359799061386a4724788e2f12fba6e3ec05db60cc6d44527e3385774d0378ea9caf1bc8dd46621c2fad9577f52a5ac14c7e3736043782ec15a2a2aa3a3e6593e4d5c2b3ab002469a264da0e0df7420f4c9c1ea4ba0f97e2af6f0401aaebd7332be7d798ac82e01b3805ddee2a6befbbb6a9ace64a47f2ab4a5f77a73e37e73adcb7967b', '021412', '[]', '0', 'hab-o-jungle-rumble', 1, '193.29.60.141', '0', '0', 'USD', '0', '2022-04-14 08:50:09', '2022-04-14 05:37:01'),
('3ab3ca04-a8db-4afa-a058-e7b8f35329ae', '2', 'b6ee2b5e9c23234c336a1f5c360de67856625fe80a4457fbb214d565568d018f248a16e5dca273dfc59512eb44feca070a0bdd1242373408bdf65b0b77e2d1f47f26a70d8528ddde12dddfb6bcb8bb6c7bc350f143ddb2ca370045204b77039a8234fd77fc0ec02a405cd8f9f6430421', '021412', '[]', '0', 'net-t-starburst', 1, '193.29.60.141', '0', '0', 'EUR', '0', '2022-04-14 08:51:09', '2022-04-14 05:38:07'),
('407f8804-1a22-4623-b2a9-f04e6b5fdedb', '1', '5817c947c0d055f735e1c2c7843ceeadf4477d53a478cf027f6d28f816beca4285e33ac8a07f5518aa1548eb9d783b6d6a55b0e5cca8245f041b849a6d0c63be58069eb5529d0ad1ea1a6ae793ec1a724cd42babec12704860e527a43c5438b8c5c35ed966d579cd186a8864cc26319e3af83af1d348f636c9e61146a4e1f380993e11f9a6c993d27cde6c1561dbdc305b20455d1bd0196ab3578ab982888b97fb31cb8deed81c29f576c222185611c016f0fdd5558b5a1c289d1a49e3bd5c3055ac5b43fb336d96c1b4c79e71c40aee9ec90824f7087738f70985dfcfa46ef9f236d8375c05f751ac8695f8beaa7493ec7cfb898989f8e5815fb77cecfcd2a2230d215e19184c851c4e1dcbdaa886621c6b7d19149e0f67f658cae86147a79e', '021412', '{\"visit_2\":{\"host\":\"launch.slotts.io\",\"referrer\":0,\"browserdetect-device\":\"desktop\",\"browserdetect-os\":\"Chrome 100.0.4896\",\"browserdetect-devicefamily\":\"Unknown\",\"browserdetect-devicegrade\":\"\",\"browserdetect-browser\":\"Chrome 100.0.4896\",\"user-agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/100.0.4896.88 Safari\\/537.36\"}}', '194.49.52.125', 'hab-o-jungle-rumble', 1, '194.49.52.125', '2', '0', 'USD', '0', '2022-04-14 08:50:09', '2022-04-14 04:20:20'),
('469548bd-63e0-4331-90c8-3c9c8ccfe91c', '2', 'c821396de2ec3e0bfa43cb7d3c24cf096247eb70984eae250ecfd0d4d99d250bf244921413a494c379580e24c826ba6088d6b4960ceb3bfb77dff688ee5cc1fa0cb7d50e22fbe8e1c6623e13ea0d494a0b6c3891b0c21a0834b34742410073c624c7493d0461a37cc1c1a7666471d71c9519eeba9ac1cc970953ba5fce17935a', '021412', '[]', '0', 'net-t-starburst', 1, '85.26.183.58', '0', '0', 'EUR', '0', '2022-04-14 08:51:09', '2022-04-14 08:51:05'),
('470248b0-bf0b-4160-960d-227fc3f0dc56', '1', 'abc2bb89695bacafbd0a8290e52fc1f89dfb5e6d46f43768d166fb0783b2a2108e67b6930e7984a9bc298d25444209190a68518696df35cf95c204a3c00c03150ee890e8a66717988397b9e60596c19c5fa240ce7b1c5dc6e1b46f731e77e47af3b073c19d915a9a6212e5bd03f2458975d70d523d3616be700673099ddc0ba24c7374de1b1d59edd3bce4877c6413d16a10b58ad805be0f4ed541b312e2bfb1ab969ec6ddbfb5fda85521807a31b87e8d5f61df873c3e9104b52a95d83e8533981e739ff6f9f6783172a43fe8cb7aa2e3f47612d21ef09dec369b28d409fb339b39509c7872e6637a2d6d3d4ec7f3089380db77e4231e01b00f0cb0f754f83c0e409bad9a0dcdc8ac310ff7506207738d205a272f3ce702c225be8b7ab9fb49', '021412', '[]', '0', 'hab-o-jungle-rumble', 1, '194.49.52.125', '0', '0', 'USD', '0', '2022-04-14 08:50:09', '2022-04-14 04:06:36'),
('48606bf1-0e55-46dc-898a-4363657978b3', '1', 'd0b911ab19385ab15c771cf23d5a3de78633cd9e4ab910c54765326f4cfc1f59bd2097d2212e858cad6f38f59559a7c7e4d0827664b98c3482f1f803e4027948d9278a6bf7927a2529d681496f7c39fec64ec284d5f51df544685f55b5324a1006c121381f6e5e5aa52ee75764a864877e88b5237b4cfce393e8c87046957d705dde7c9abf79654e53d78689aadc82ed48e68a366616df12e159450e74f90e93fb04c94feb25b5ae665f9c99b0d043486687138bcb6bdceeae5b94260010d7f9da7c4c8d728703c985aca006376de8e459e3f665f73607dda3e131943556a0642b385fb194665c95889d1f3b72142fd43da1df50bcb9ff7fa03c90250210585ca8d046c3f099784859f7002eb516817e0e044c9b466025ee245506ab74c9ca67', '021412', '{\"visit_2\":{\"host\":\"launch.slotts.io\",\"referrer\":0,\"browserdetect-device\":\"desktop\",\"browserdetect-os\":\"Chrome 100.0.4896\",\"browserdetect-devicefamily\":\"Unknown\",\"browserdetect-devicegrade\":\"\",\"browserdetect-browser\":\"Chrome 100.0.4896\",\"user-agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/100.0.4896.88 Safari\\/537.36\"}}', '193.29.60.141', 'hab-o-jungle-rumble', 1, '194.49.52.125', '2', '0', 'USD', '0', '2022-04-14 08:50:09', '2022-04-14 04:25:03'),
('4d5bbdae-9d51-4ca1-8154-ec4fe85640f2', '1', '6ef55c093a481f22c2d0fa59dc0b690c1876efd01ce565b0744e2eec834f57ba009cc7fe7d352f84136e6978f6a61331ed4a84efda3c338a4acb343869a8534b1c6acf3ac4e3643ba83e8647da53a5cb54ffb19ed4def8ffd883c920c27913147e1f3f1194fb9ed381b919976c6a019b38b7f9dfdae54db001155238362d0ba59729d769cc54e4536af3b2b1570bd655a1a0fa065f95a4c4c0d444853bf3d68ce62b2f7039321b335cb203ba0a954a5c0bed60543f415f428d770ed859406726da3eb130e752321f698ae94accb52b97d14d100ef30d9b43e809d34df8bda1fb86ca38a0932760d7c517b6f032346638cfe0a11e0d02f0040e173bbd385d194fbfe189a839f18ab9dcb80973785cf4773ef46dcc2b9921dc5fad945e63e87195', '021412', '{\"visit_2\":{\"host\":\"launch.slotts.io\",\"referrer\":0,\"browserdetect-device\":\"desktop\",\"browserdetect-os\":\"Chrome 100.0.4896\",\"browserdetect-devicefamily\":\"Unknown\",\"browserdetect-devicegrade\":\"\",\"browserdetect-browser\":\"Chrome 100.0.4896\",\"user-agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/100.0.4896.88 Safari\\/537.36\"}}', '193.29.60.141', 'hab-o-jungle-rumble', 1, '193.29.60.141', '2', '0', 'USD', '0', '2022-04-14 08:50:09', '2022-04-14 04:28:15'),
('54be3162-6b70-4a4c-8c28-cd792acfa34a', '1', 'afda30abd8272cbd26c8d1284456c18499fa1128d6a0708ed1c213829ec0ac919669569e923e35025818b8189b24b7f286de18f3ee7f010a90abc961f3fcddc74442ad3c3e4b062cf55da4d0bb8be9b96531c55268802d2023189067299aa9475cc7bc8895a12e9a33585eb022c3074668ed0aeeab2568d7de98cac705d043d8d87683a22da940a953c88ca6e01a007006c300478f25de4eb77bc7dae788e2a751a8aee5232171abd763f7bb4e1e16a0fe8f3dc5374ed5d3323f54d6974f0c0afa7687611119b917d232bf31319742fdc3de2db095901bfd682bec56a5a5a0ee8db6d3a1ee63d2fb2e04ceed685d998a080b1540fea53044d23c2c00b55e0a2cad88d3d619ed6771f0cde75c973d7cc8e4b9874186371c54320e6901285fa9bd', '021412', '[]', '0', 'hab-o-jungle-rumble', 1, '193.29.60.141', '0', '0', 'USD', '0', '2022-04-14 08:50:09', '2022-04-14 05:34:56'),
('6447e99d-27f2-479c-ba15-2d3534734278', '1', '9d722e6653c1aeebc96bfa3bd85c15acff3f2f9b6ba659078e65fc960859aeb34bd288896879dd0930a857e980456d51d0fe4db0d77564c045e7ce71047d2e96b843580a1d1e6d025a943432d4de66ac3af2376c41a3c74516ef5850420ef9c5ced752f9eab18206584921297b3dfeec153aa4c973ab1eac0894ea3e253a172dc2d925dba631bbd782281eb465cad5aa2c62844a589f17c66250ce9ebeb9fbb33d45275dcbfd0589d130d77f667c12242ee67295d38dcb21de6913401f88826747109adcfe1dbc022a09669b2b1f61944a6c387699228bab97ff665c48f170fb59ab1bbe9b73b37873126b3c16f6dce4ca1f56d53eff902ef1e7612419fdfb394227e8a4431b5ba4c973f7e0cbfa44080b1b729afa325fb46594478ec5585722', '021412', '[]', '0', 'hab-o-jungle-rumble', 1, '194.49.52.125', '0', '0', 'USD', '0', '2022-04-14 08:50:09', '2022-04-14 04:24:53'),
('6b1d826b-8d33-45f8-8086-ee28e547602e', '1', 'efc654fc4e403a8358bbee511b6dc625ee9a5c6a17c201507e8d5a4983296e7a7a455efb45ebb75c7271b24608640e72d924a79dcf6f2b78cb33a06e156b157ab10dc0b242e91da716ed683797fdbe57a700ec5b165574555678043abb1c7021f2c9bdf0cef8349c9a1c283a23555e06b186bb93f70c1442af58c27375daf640bfc473c18a194e502dae852527ff5ca721fe8ff35132813d9f6e9c4784c3670c41607a4e91e41c6e27dcf730beab37ffe8f2fc21219b9b7dde74fb2dc04ac1f36240b798d0a89cb839d986c29fe04c083554f346a2bb0e9cbc253d2e9ca75405f31d21a9ead9f7a4c8a3a649d0f72bdda0e6b30bbe4f1607667784ed254c9c0e657b7a75da5366016218d353773239f122618c4ec9f24a699b8e3630a5e53e41', '021412', '{\"visit_2\":{\"host\":\"launch.betboi.io\",\"referrer\":0,\"browserdetect-device\":\"desktop\",\"browserdetect-os\":\"Chrome 100.0.4896\",\"browserdetect-devicefamily\":\"Unknown\",\"browserdetect-devicegrade\":\"\",\"browserdetect-browser\":\"Chrome 100.0.4896\",\"user-agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/100.0.4896.88 Safari\\/537.36\"}}', '193.29.60.141', 'hab-o-jungle-rumble', 1, '193.29.60.141', '2', '0', 'USD', '0', '2022-04-14 08:50:09', '2022-04-14 05:36:38'),
('7a72a8a6-2915-4f9b-9c5f-e770ecfb6a9c', '2', '3a85e8a02f566ef8eeefcc4676a4326869770091222e40402c602704e020cc4ada4466263154c292f82a8505b716bdc029f180789b66e1bd62332fd6afaf3ffe47f371f8b502d9a54a869002d829650c98571f9cb0f6f9d4cf37a9fab8301c5b6805ad1c05768a7e9ff1b7be233d5813c85ccbde0270761c703312ad17a2c8f8', '021412', '[]', '0', 'net-t-starburst', 1, '85.26.183.58', '0', '0', 'EUR', '0', '2022-04-14 08:51:09', '2022-04-14 08:50:20'),
('7ad5e60f-e34d-4457-8cd2-7474eccf37ea', '1', '36f24c3f0939487bf4e17cd762d27e392eb1312c24fac6930fce9017b05621a2875fda69bfda67cfe73ce7ec73a32474e3f4dc82c262d7064097719ee379cf3754195be7b27fddee7e50e918da037f842a51f162142f167c32cbef05eb51820eb0ba45feff964dc2fe18c04412593ef6937a4e71a5527fcb1e643472eaee4934ee8c5014559d28d2226b0d563781b551a8447355e858ec845ead5bdfe893a257977acdfe7f8ff58f7cd7aa520ef5986a094e6328bc9848a0bac42a48de1d92792a70c0322b015296105f57279e9ba538c00b8a67932c8be626ca49b571613df276194be8e57c14ca1484a9acf67943e33d2af2dc406b1ac08ebd517ecbe6008cc7534f850594db459930dff7c56318d4175ade17e440e99ad3e9f731f025c6c8', '021412', '[]', '0', 'hab-o-jungle-rumble', 1, '194.49.52.125', '0', '0', 'USD', '0', '2022-04-14 08:50:09', '2022-04-14 04:06:28'),
('7b974adf-0107-416c-81e1-fdbd1035a495', '1', 'f0bc8fd9b95672b097e6a4a04f11be5602078afe1b8ea1589918c6a8ca8897c863218935b920374ca4d7f1d854688e00206ce448ae65fc625fabff59dbc040ad0fe440a40a2b1dc6c0120819d6b16d0a11dc65e2e68ddbb5f76e760e6d7715ab0671e213f2f8d737fe6ecb191e4ca95b4a0cb00eafecb78b13f4e493cdfc60a4ed61e9d797f4da0c8daffaefd74a9bc636892cd0a9d96f05271e8ec67bb37b6b93364722cd2e70da51895f51706eda2e47b41209ebb913e6f7ad14caa5ae057eddf22e20b77edc09c28010b109a8a691b118ad17b96ccd75b4288a5c92159a284340a13138e87a0d2a225ad548dec6f2194bc2a2fd28c3638a3ce0c2ec3c2a166479ecbb64d113a6f642a477d6fe74a2cd6a8cf9d2b28f57f75bcbf011304ed2', '021412', '{\"visit_1\":{\"host\":\"launch.slotts.io\",\"referrer\":0,\"browserdetect-device\":\"desktop\",\"browserdetect-os\":\"Chrome 100.0.4896\",\"browserdetect-devicefamily\":\"Unknown\",\"browserdetect-devicegrade\":\"\",\"browserdetect-browser\":\"Chrome 100.0.4896\",\"user-agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/100.0.4896.88 Safari\\/537.36\"}}', '194.49.52.125', 'hab-o-jungle-rumble', 1, '194.49.52.125', '1', '0', 'USD', '0', '2022-04-14 08:50:09', '2022-04-14 04:11:50'),
('7fe0dca7-cfb3-43f9-95b3-4d792bda500d', '1', '21000cd555e900d6ac8abb8c6489ca3b1cc3f4ca17f80a5aa9196c69bcd28faa62e72d31ece48e1bd532f32e206796b698dd38070d0b64ca076c5bf659bef39d94ed6a946776b9218550fed7f9c574182b65ba8901b64c1b4ccd50eb3f2646e37e9a732fe8d9cdbf3f3cabe0ed9718f12f9fa5140b21f08ce27c41d5fbf80d7b717af260b4d75dd9344459ffa9b28c2c0e41eb5b281556ee945afe7d09e154d96f686ece1fbeba556154f4cfef0d36f81dc0603ededef831256911029b05740b7d0666aa556688fc1e278d7fbfe7eac620564034d26520bc1bb7fa567361a67f23805000094dc3abf99d012c09fd20db5b84d1cb70f3917f210a8f0a31077e7ed4097584292c1a3aeb0ef323aca8a03d8c0e8e091afc1d7202e14087ebc94506', '021412', '[]', '0', 'hab-o-jungle-rumble', 1, '193.29.60.141', '0', '0', 'USD', '0', '2022-04-14 08:50:09', '2022-04-14 05:48:01'),
('85ddeab8-9d3f-432c-8304-9b4377632559', '1', 'dee9ef0551576afb3787076d73fe5c84f1f276f4f2cdcf188e7343d63580a0f860bb70fbfb526e269e0cf0a79f7d06f72baa1675a9b3c9ab0a2609123c8e04193bd4e800eb368ae6e82743dac557905f126087f55d4c8ad2ee58019ca6e38a9b5c38b126fc045896907a9027d4859a831857e0b19cd441e9c6fcd2d58873a8d0a8cb5f1bd8fed5b30057045f8a37afa95ccfe989d1f22598661be59ea677cd3d9427ddd48194ffa9de3182d0032b4d7a343db8cc935970311818f5fda9a0cb1763f9a411c12c40a165ceae6bf1499a1bb2c4dd13ec8f189e87e388976c2818ec9216b99735ae00e7cbf078ed68edcf300dc17ab0c66355dc280fc29d67b5ce9622038c5a9e60452ef3c1ea00883e8484c0f223e692698a1930f18739c726a1e6', '021412', '[]', '0', 'hab-o-jungle-rumble', 1, '194.49.52.125', '0', '0', 'USD', '0', '2022-04-14 08:50:09', '2022-04-14 03:50:21'),
('8e0939a0-8362-4f34-8a4b-fa99effa4b4f', '1', 'a8639ba98427d2736775c36dfdd45a1885fd4d0b8cd71ae7cbb5601fc51de53b16d7ac8f91feb07363ffedbf653d01374b7d545bdfc9156444f94001d36e9fedfaeefd17b83f357c74cb7343285381787dd778badf2adcc2490bc7cef4ec96fbbd330ee86533eaeeddc922d0b6d3664c65f2272b2e3f8f97e82dd03791a95612d331a4fa60df4550f540355bf697b8b791d472ec6ecd99d9d8b12fdb5815c3a6c017a4be82eb0093135e44789281e3f3b09d67c0870b6de80bf5adcebc11821b8ffdde2fcfc0f33f128ea31475ceaccc19c98069f742a32d3a4cb93c0fbc15631fc66a1f0a08595a1ef5249fd4855c4886268cae2a8fb7dc1c48feca5ea53d41f31a52f6eee30f2f590f9057988f27e4b2609ca5b40c956960de8b03adb02e49', '021412', '[]', '0', 'hab-o-jungle-rumble', 1, '193.29.60.141', '0', '0', 'USD', '0', '2022-04-14 08:50:09', '2022-04-14 05:34:47'),
('943f2532-fa52-4a96-8e78-647a103897b0', '1', '392ac15aa876bfbc3f8077c56886fa429ae8d40b07ca4ff096b0443f695198b9d6ce116c8a6dd3e180393819fe72d2b8949df91313842ba0e5e731ba735fa0aea9aa0db310dee6df01ba09ab039a58271b059eb3974f602f7f7d4bf1aebd0eeb84b4a8a806e496c291c956c9681c8d299e3fc4120f4f0220c2f9838d9d801d09563f16d608a129bb916ced791b2865dbb9780660e5cdb1cf1df8b529f5b7f4eaf5c2f96fc335406414337a4a68814b43dcf7c13e3df8d0af2abaa3905582f3bcf89481e3cba39855494c1bdde910850ed68d679e528132f83d67eae3291c510562e5338ffaea2f977242a2853f1bc2d8e46f6ea0e1c5fc8b62d74cb352cacca6d2b010e4264f13350809feaac278aadb4e5c16f53274b87250c0660ee44cab90', '021412', '[]', '0', 'hab-o-jungle-rumble', 1, '194.49.52.125', '0', '0', 'USD', '0', '2022-04-14 08:50:09', '2022-04-14 03:49:06'),
('94c3e3eb-122a-43a4-bf98-021e2e306478', '2', '20f9256e1cd121ba6437929b3896af3ea730b47b399d15fd691f8ee2997fd98baf496a1c98cafcdddebc2be0945b68158b3b1a7124086cd6190c82a53fe3dba47adb8735f52848f2d0a5d423476853c6c3ba6bfe635408d650711e7f429911f646124741abbc484684b1c5de881356d8', '021412', '{\"visit_1\":{\"host\":\"launch.slotts.io\",\"referrer\":0,\"browserdetect-device\":\"desktop\",\"browserdetect-os\":\"Chrome 100.0.4896\",\"browserdetect-devicefamily\":\"Unknown\",\"browserdetect-devicegrade\":\"\",\"browserdetect-browser\":\"Chrome 100.0.4896\",\"user-agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/100.0.4896.88 Safari\\/537.36\"}}', '194.49.52.125', 'net-t-starburst', 1, '194.49.52.125', '1', '0', 'EUR', '0', '2022-04-14 08:51:09', '2022-04-14 03:51:16'),
('9536b14d-fe94-4fc0-b3ad-aeede6abe3bf', '2', 'c2d056ac38d8090916250d7659d7f14ab0d433c7bf32bab25e8b9af93963a9a4ead0e546f3f4c1b3c1c06ec039b8f2a8f37ae77c17e0cfde76f62dde1a0f144c9319e6213365e52a7bb75bea0e51eebee4c36a81904eb075b2db318b25b31ef4e1696b8625585b106a58f2bd2bc66a44', '021412', '{\"visit_1\":{\"host\":\"launch.betboi.io\",\"referrer\":0,\"browserdetect-device\":\"desktop\",\"browserdetect-os\":\"Chrome 100.0.4896\",\"browserdetect-devicefamily\":\"Unknown\",\"browserdetect-devicegrade\":\"\",\"browserdetect-browser\":\"Chrome 100.0.4896\",\"user-agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/100.0.4896.88 Safari\\/537.36\"}}', '193.29.60.141', 'net-t-starburst', 1, '193.29.60.141', '1', '0', 'EUR', '0', '2022-04-14 08:51:09', '2022-04-14 05:37:31'),
('a14ca1fb-2202-4add-8175-8526a76ee492', '2', '88d322903f1dc21004b811e9f6de4343f3a3795748e683c7c453757801a62e5c31511d5fab69fc90db50cded14f82c91b310ffc8aabbb97f66fdfa4cfab6365ff6a4083edc098422eab39db37164505b1c19d7fbe85b00a0e82d9059a551d5502e1c33af5ea6b4e9ac1c16896ca87ab8b0b053f4b388170dd57f51a5c9b9e2b6', '021412', '[]', '0', 'net-t-starburst', 1, '85.26.183.58', '0', '0', 'EUR', '0', '2022-04-14 08:51:09', '2022-04-14 08:50:13'),
('a823efd7-da80-40cb-8eef-e23e964bc400', '1', 'eeb98279317e5de0d7845391525c6277356b6ae7da5935d96e3e44bd59e45d71dfc5e040acd4d2ce170f4431001a0a954066b018c82ae0e31bbe1c8d445550558a18e980fac2f28864e74b8329e978d70bd09de52b1facbbb2eaa6fbba6b582ac717f053469eff12cc152bfeb42fe300e62278de9447e954b2fd9185d38fecda6aecee0bbaf06c19c6820ee2c5cd927e6a1f8e4f5eacdaf92f1e5ac79506948013d9ec6f76a067253da6da47b6910df1c9b09525a975280f6262b218b231baba1a5b0aa085cd916786ad869f53ad463579637592a9324ff3f9e5b11be6be14058a7d56eac6c27a0ce5ee41e653d4ccefef6702e7d5e21144a777e2159bbea24485a08f1eef29021793063fa7ca004ed0b0eb7a2b86808160bc61b63ad8978c2f', '021412', '{\"visit_1\":{\"host\":\"launch.slotts.io\",\"referrer\":0,\"browserdetect-device\":\"desktop\",\"browserdetect-os\":\"Chrome 100.0.4896\",\"browserdetect-devicefamily\":\"Unknown\",\"browserdetect-devicegrade\":\"\",\"browserdetect-browser\":\"Chrome 100.0.4896\",\"user-agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/100.0.4896.88 Safari\\/537.36\"}}', '194.49.52.125', 'hab-o-jungle-rumble', 1, '194.49.52.125', '1', '0', 'USD', '0', '2022-04-14 08:50:09', '2022-04-14 04:07:44'),
('a8830c26-f21f-4e73-bc0a-def3736cfe30', '1', '7ac4db27ef00374e83d0a167ffffc5a5f8ec2d63af7cb4530c9e208da8b8febb8ff500cb993acbef70d7858ddb78d258a5a957c0dd65085ca7ba2d8de526198c79fff2c644869c1fefa900d51e1dafdc9bd609d5b68235f02593069f10080f61851f92faacdf3d441990e3ad19cbbc73e6ae6ae00b4e3e944089e1edf79c3b21d639385c89182acae651886c0a68bbf869f3a89265a9ce8bb907db8c2b73a56beb40da6531fcb2f1fe09d5834abdf1cd5d84ab4375dbdf0fe4768cba4948de7475d6408480c7cd5d7fe3ad2cde9b4dcbf947de05d24da4292abfd442c9e6ecb101cd1384eb8b2c70dd1702c0f9b19db71624710cb9fbd8692a5a1b3e2e5a8b19515d969c994191c34e5f2be6200805343d14654f8a1b5df0114050aaa59aab7f', '021412', '[]', '0', 'hab-o-jungle-rumble', 1, '85.26.183.58', '0', '0', 'USD', '0', '2022-04-14 08:50:09', '2022-04-14 08:50:05'),
('a9dfb59c-17bb-44c0-a630-ae69468334dd', '1', 'f2888aeeedd2faf875c1afae70aac5f0136db78bc546aed2147977035f4d80d6aa0e3ae138af19402627bf19fb4b76c9e37a76c4ecd01a027bdc51bf26ec6987e2a3b0d2529f6cfdc14dded4f2bf8c02ff3e3652258939a854e259c080896444dedf6bb287678b5ea4a189df43879cef5993a89efd7ed52b8cdc9077f7fb34d84e90cc71baeb9024a9b43cd0aebdf77acc59c371b66274bd529ca7709e6ecfda43aba69cafea8af2d5b05c3d7494784fe4dda74463af50f6d0b9e01f91c7db54ec3e3bdaa53c052e12f4f9847e0c47dfe1aaba57eb05b6e2f24404e2a6c61818f202cdeb981db0eef5a82db111a58426c209f3bc5786602202abc84c186cd12f93d2bfec14b9ac1fc5f4ce684bf4d2e5bce4be86b9043daa852b81db44099953', '021412', '{\"visit_1\":{\"host\":\"launch.betboi.io\",\"referrer\":0,\"browserdetect-device\":\"desktop\",\"browserdetect-os\":\"Chrome 100.0.4896\",\"browserdetect-devicefamily\":\"Unknown\",\"browserdetect-devicegrade\":\"\",\"browserdetect-browser\":\"Chrome 100.0.4896\",\"user-agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/100.0.4896.88 Safari\\/537.36\"}}', '193.29.60.141', 'hab-o-jungle-rumble', 1, '193.29.60.141', '1', '0', 'USD', '0', '2022-04-14 08:50:09', '2022-04-14 05:35:27'),
('acebf122-4921-403b-ab4c-061052fbb95d', '1', '2fd0655ff7a71f5b122916cf20b7ed4f3b55407951c5ffbd7321495a468f2320715b7a31948932fa21cb507ae78a321f8407276221f9d326e7500b6cf8f5eb2494becc1864dda84dfeea40a70cd6597720b85e3efb1bc2c3dacc451beb189525106efc193370cbee47271302db45f0c0cc9066cf6c3d3042d5c47e9b4084fed242bfc782ab8e699f6f0d5c38ceed6c48f110c860d3924ecd476536a62d7efecf6298f04a8847dff9870a885f37bdb28ff15b388be44fb6a1c92c34eaa4d823bc6cfddf21d84ad12e5f16f2a961440c22681cb44f5c3746240e6bec278a3c0839827b9ee0e1185802ca294238e289379c08737b96b420ef38ee6ac30902bd465c854623c432ad922d4c6616b9433de05f0b424ca5cbdef60843a4f35db062c2aa', '021412', '{\"visit_2\":{\"host\":\"launch.slotts.io\",\"referrer\":0,\"browserdetect-device\":\"desktop\",\"browserdetect-os\":\"Chrome 100.0.4896\",\"browserdetect-devicefamily\":\"Unknown\",\"browserdetect-devicegrade\":\"\",\"browserdetect-browser\":\"Chrome 100.0.4896\",\"user-agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/100.0.4896.88 Safari\\/537.36\"}}', '194.49.52.125', 'hab-o-jungle-rumble', 1, '194.49.52.125', '2', '0', 'USD', '0', '2022-04-14 08:50:09', '2022-04-14 04:10:27'),
('be5abcfd-0b81-4076-89c9-a0e96fdc72cd', '1', '96cfac36a76dba92063b3222b4a45be268407022b9bf33fefb86708c3706ab78d781b88c3e65f41035fa7e089b977efc71fa7b064aaadfca6b806af43452199009ff461251859d238d67e42c0c71d48fcb627f57d148f199a328111e09819e3f2de43954c79a4a60788b2853267798d021d4bc304b94a570f21cbc7904105de4e45ce75de4ea51b6b8c4af0927524ea09233379a711a469239feaa13ad046187b0ab3de07a164a7d11f21d7c1e2e6f07b24709cb4593cf42bacbf91ec4118a86ed8d771f039cfe555fd450064a22e97d020a27d7531b1fb40c9cad8e96a89c3dfaa1cc9cab06f7ae316cbfa2122d80c868070517e793cba2182b2fc1b9e774b5387967ffc0b3f1ac3c59223c6054cc4d0552ca14a7ec8775171565fbdcb9f615', '021412', '[]', '0', 'hab-o-jungle-rumble', 1, '85.26.183.58', '0', '1', 'USD', '0', '2022-04-14 08:50:09', '2022-04-14 08:50:09'),
('cee112ea-8957-4ea8-9603-9fef2f9c3b75', '2', '9f9b7c11a7ed0166f5b04407446ac192154d298ec936bf877dc3d01b8e4875be94fb76623007521a562b5f6e1db9c2108afc5392eacb6318755e70a9dc78ff3af138deb003a9fdb49b94ae07212fdc041f63b87ec834a8a7675337bad31f1b9776f18b18a93796f33cd4848c655518ce50e549523572a90f5fe8f5d43aa6a132', '021412', '[]', '0', 'net-t-starburst', 1, '85.26.183.58', '0', '1', 'EUR', '0', '2022-04-14 08:51:09', '2022-04-14 08:51:09'),
('d195d86d-9d15-41cc-96d8-a9843ff938a2', '1', 'bfdf904920ae0b56377343a8f002a2311ceb47b7f41e94a90fb32490213042ac556ef35987cf3c548ac8c12b0c8871b09f593ed519b3371c15d851a63ffe14d2b816350c769e1ad24b28fd040202cd6b5926c1de9e1ab914397ada0fa7c6063515fc72f032ad095ba355db9c3eceffefe2b74f1ed634360e065ac6205b1f3c365cacad2b0077974a55a082cd6dff672004e68d966bb84c23f7324982822b9b7cfad77f95ff3ebdfa78b4276548a3605522bcdb4a0758a5c7907d2aa8474479d31ba54b5238fee52a7b1f8b1f74dba9c8f2cd326a3b4f860b632a2d9415be155de1ded6c4002b40ebda6341f76bc6ef04cda58b5777dbf6f1dbaa968d7899618b73b9d19dfadd26d33cc71fc88b3fb420628390c96702202078db414b457c6472', '021412', '{\"visit_1\":{\"host\":\"launch.slotts.io\",\"referrer\":0,\"browserdetect-device\":\"desktop\",\"browserdetect-os\":\"Chrome 100.0.4896\",\"browserdetect-devicefamily\":\"Unknown\",\"browserdetect-devicegrade\":\"\",\"browserdetect-browser\":\"Chrome 100.0.4896\",\"user-agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/100.0.4896.88 Safari\\/537.36\"}}', '194.49.52.125', 'hab-o-jungle-rumble', 1, '194.49.52.125', '1', '0', 'USD', '0', '2022-04-14 08:50:09', '2022-04-14 04:12:12'),
('d6a2f3c7-3bb0-46bb-8e34-8650512ae014', '1', '798980ac7423a7d0eec36d6fc8403ef1f88a3489aced8a40c412b82466d98f4aff32dd3f14d08b77f0d67e48ac45e2cd7aa702c26467137c7409f84ac6d0fe1c8b13516c83ad9a1ec1be48ec9770269e73cd34ca5aee153e36c22e8d1ba237ec2bf468b625a01bbe1836fffa63de231b35e60f4b0219cda13320fc53b58a28010edfaddc8d5ca57d3f59dc02198f08720f455d33b4bbeaa67ee761fa5959b820fbeb41f2d9d54815c5bd9c4ebc3b5d9bed77192f534598c0f7f0d59cb45587c8e82ef0f610178b25b7365810b17d6b1f4247ad77bdb760a854d5634d4534e4ceb9b403c183d278e8313e48184c2169e8921b3cf2dbe47d955227579cb01e3b93bded54449a4519eaf087ed0ae0b49e25efd31d9936f8983e651b94847590d40a', '021412', '[]', '0', 'hab-o-jungle-rumble', 1, '194.49.52.125', '0', '0', 'USD', '0', '2022-04-14 08:50:09', '2022-04-14 03:50:21'),
('d6bc34e2-e0e9-43eb-a94d-606fb9ad317e', '1', '0bd5ee83cdd69dea2b6e37733bc2597682e8947c719e2ca22506204453bbe393a2219010c19b136d83d183bde1b434ab4bdf1140c719db82bfa122df11a2fd42a125f259311a0fc271fa0c8eb01c87bfb1acc9bd7c56f997e27a588f80048bccc08cc96e6193de470dff1011f99933162a66dd5f28a37b6f86d16091c3b1e1eb1cddf82a3003b13126406c3ad532a7257fea8ded5f3304ca70e0c8d98d5c69bccf3ad8d69640c30d3050b10baef5f25e3f9bcce2060480696162ee6ee82a352e12738d34d71c3b4113dd817f2d99a234fbe5fba83d0057cd4a2be65d07280f7fd00228675b7132973a70d0063ac187e18c02e4ea24a33ba22b78db937b48f635dde4508b01d0f23fd010647dc6d33d3bf5ba9d2c329375c5deaeab91eda4b0e0', '021412', '[]', '0', 'hab-o-jungle-rumble', 1, '217.146.87.149', '0', '0', 'USD', '0', '2022-04-14 08:50:09', '2022-04-14 08:44:07'),
('e462fb44-2802-4f2d-80a8-5005cb57f4e4', '1', 'e1e7e907023470769f6f55f81609eb8bfe271c975968b3b6369bf191c915fe07855886414595aa561fdf8c8f52609e10dc21f4536713fb826c9780adb7a37886cb6e3c84f17ce252c2d68a8d0a18cfcc6c6ab3d001f46f5a645581bd13639f070d268859134cbc8e2d5141f5a8bb2f8d05796757938fdedca5fe1c112a2f210d80f0d6bff5a72061372caca37ad1203aa2ada68786cc714671d04380f241845038b388d77f0f5ce2c28f51670edd78a8be0faf1f43598d4b41de57b238c6669e1e25cb33167fac0e92d1150c2ada001adadd5dd427b4bd3494e6d49ca5b7a09232619ac5aa1c63ece279fd828159329d4afceee39393e41f902c8ca2bffdf4f238a003887b1034dceac8ed08b67162c6d4dbd153a8450f8c63b366b07615311b', '021412', '{\"visit_1\":{\"host\":\"launch.slotts.io\",\"referrer\":0,\"browserdetect-device\":\"desktop\",\"browserdetect-os\":\"Chrome 100.0.4896\",\"browserdetect-devicefamily\":\"Unknown\",\"browserdetect-devicegrade\":\"\",\"browserdetect-browser\":\"Chrome 100.0.4896\",\"user-agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/100.0.4896.88 Safari\\/537.36\"}}', '193.29.60.141', 'hab-o-jungle-rumble', 1, '193.29.60.141', '1', '0', 'USD', '0', '2022-04-14 08:50:09', '2022-04-14 04:29:33'),
('f57db2fb-9161-4ec3-a039-2aeb8c665c4e', '2', '37b63e411a26b84e1206997f19a8b37539c08cf3abc0b84e4850a68b6edd55ed5d02625fc4e5583b9f0cc7ceba04fc2252a8901748f4270f1372108e29ce3e4b2abbd468cdc2dd4a828a3dfa309b15e102c0a0f359e5ab92f823a840bfe3ca931cec845592fc1e7cca66a1657d85f29d', '021412', '{\"visit_2\":{\"host\":\"launch.betboi.io\",\"referrer\":0,\"browserdetect-device\":\"desktop\",\"browserdetect-os\":\"Chrome 100.0.4896\",\"browserdetect-devicefamily\":\"Unknown\",\"browserdetect-devicegrade\":\"\",\"browserdetect-browser\":\"Chrome 100.0.4896\",\"user-agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/100.0.4896.88 Safari\\/537.36\"}}', '193.29.60.141', 'net-t-starburst', 1, '193.29.60.141', '2', '0', 'EUR', '0', '2022-04-14 08:51:09', '2022-04-14 05:38:50');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `admin`, `created_at`, `updated_at`) VALUES
(1, 'test', 'test@test.com', NULL, '$2y$10$5tOPSJDNVaxJyPtEtKiXWO0XwtN2VpXp8vQQycWiHexW1sUUdvU/e', '8bF4o3iS9IDgo717qFwQD3V5mW55dUAgMg2tbKjMZa5L7iYBsaXpDK4dJByd', 1, '2022-04-14 03:36:33', '2022-04-14 03:36:33');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `access_profiles`
--
ALTER TABLE `access_profiles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_unique` (`profile_name`);

--
-- Indexes for table `access_providers`
--
ALTER TABLE `access_providers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `access_providers_access_profile_foreign` (`access_profile`);

--
-- Indexes for table `action_events`
--
ALTER TABLE `action_events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `action_events_actionable_type_actionable_id_index` (`actionable_type`,`actionable_id`),
  ADD KEY `action_events_batch_id_model_type_model_id_index` (`batch_id`,`model_type`,`model_id`),
  ADD KEY `action_events_user_id_index` (`user_id`);

--
-- Indexes for table `currencyprices`
--
ALTER TABLE `currencyprices`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `currency` (`currency`),
  ADD UNIQUE KEY `currency_2` (`currency`);

--
-- Indexes for table `demo_sessions`
--
ALTER TABLE `demo_sessions`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `gameoptions`
--
ALTER TABLE `gameoptions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gameoptions_parent`
--
ALTER TABLE `gameoptions_parent`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gametransactions`
--
ALTER TABLE `gametransactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gametransactions_live`
--
ALTER TABLE `gametransactions_live`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `log_callback_errors`
--
ALTER TABLE `log_callback_errors`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `log_createsession_errors`
--
ALTER TABLE `log_createsession_errors`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `log_important`
--
ALTER TABLE `log_important`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `providers`
--
ALTER TABLE `providers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `regular_sessions`
--
ALTER TABLE `regular_sessions`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `access_providers`
--
ALTER TABLE `access_providers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `action_events`
--
ALTER TABLE `action_events`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `currencyprices`
--
ALTER TABLE `currencyprices`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `gameoptions`
--
ALTER TABLE `gameoptions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `gameoptions_parent`
--
ALTER TABLE `gameoptions_parent`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `providers`
--
ALTER TABLE `providers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `access_providers`
--
ALTER TABLE `access_providers`
  ADD CONSTRAINT `access_providers_access_profile_foreign` FOREIGN KEY (`access_profile`) REFERENCES `access_profiles` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
